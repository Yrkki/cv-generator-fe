# Security Policy

## Supported Versions

Versions currently being supported with security updates:

| Version | Supported          |
| ------- | ------------------ |
| 1.x.y  | ✅                 |
| < 1.x  | ❌                 |

## Reporting a Vulnerability

Vulnerabilities currently managed via [Snyk](https://snyk.io/ "Snyk") on a nighlty-build integration basis. *See*:

* https://snyk.io/advisor/npm-package/cv-generator-fe
* https://app.snyk.io/org/yrkki/project/d97f9a46-8516-4586-b455-e072b62ce854
* https://app.snyk.io/org/yrkki/project/fa16a2a4-b6e4-4261-9c6e-b02397763950

Report a vulnerability by contacting the author directly.

Remediation to be expected within five days.

***

© 2018 [Marinov](http://marinov.link "Marinov"). All rights reserved.
