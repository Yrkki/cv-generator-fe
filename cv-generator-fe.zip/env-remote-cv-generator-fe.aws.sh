#!/bin/bash

echo $'\033[1;33m'Running environment setup script
echo ------------------------------------------------------$'\033[1;33m'
echo

echo $'\033[0;33m'Setting up environment...$'\033[0m'
echo
pwd=$(pwd)
pwd
ls -aF --color=always
echo

aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_FE_APP_PACKAGE_NAME" --value "cv-generator-fe" --type String --overwrite 

# aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_FE_DEBUG" --value "false" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_FE_DEBUG" --value "true" --type String --overwrite 

# aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_FE_SKIP_REDIRECT_TO_HTTPS" --value "true" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_FE_SKIP_REDIRECT_TO_HTTPS" --value "false" --type String --overwrite 

# aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_FE_USE_SPDY" --value "true" --type String --overwrite 
# aws ssm put-parameter --name "/cv-generator-fe/NODE_TLS_REJECT_UNAUTHORIZED" --value "0" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_FE_USE_SPDY" --value "false" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/NODE_TLS_REJECT_UNAUTHORIZED" --value "1" --type String --overwrite 

aws ssm put-parameter --name "/cv-generator-fe/NODEMODULESCACHE" --value "false" --type String --overwrite 

# # keychain
aws ssm put-parameter --name "/cv-generator-fe/NPM_TOKEN" --value "42170b47-1dfa-44ef-b3cb-f3e00ae3fb8b" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/CODECOV_TOKEN" --value "b83acabe-5242-47bd-b085-3d01118049da" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/CODACY_PROJECT_TOKEN" --value "bc7b934f548541d88f3e01fcf141e545" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/CODACY_API_TOKEN" --value "0jDTZ9LSGPJX60KQDgCn" --type String --overwrite 
# aws ssm put-parameter --name "/cv-generator-fe/SNYK_TOKEN" --value "05ff0e13-15d9-47d5-b3e0-90f94edfcda8    # @appveyor" --type String --overwrite 
# aws ssm put-parameter --name "/cv-generator-fe/SNYK_TOKEN" --value "c66f807c-8a9a-439d-bc8b-dba6df8b10ff" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_APPVEYOR_TOKEN" --value "06i5dd4cg0rg9y3rjej4" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_DOCKER_USERNAME" --value "jorich" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_DOCKER_TOKEN" --value "723be3bd-50b7-4e99-bc1b-fe661fb61eb6" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_GITHUB_TOKEN" --value "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" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_SONAR_TOKEN" --value "0dd8ca76c1166fda12660c093f5d54d59cc71a85" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_CODE_CLIMATE_TOKEN" --value "62f633fb9575890afc28f3c473d032c31bed3bbb" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_VELOCITY_DEPLOYMENT_TOKEN" --value "62f633fb9575890afc28f3c473d032c31bed3bbb" --type String --overwrite 
# # other integrations
aws ssm put-parameter --name "/cv-generator-fe/DD_AGENT_MAJOR_VERSION" --value "7" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/DD_API_KEY" --value "ac009977adcf4906389a7ca73d963623" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/DD_SITE" --value "datadoghq.eu" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/NEW_RELIC_ENABLED" --value "true" --type String --overwrite 

# # other config
aws ssm put-parameter --name "/cv-generator-fe/NPM_CONFIG_PRODUCTION" --value "false" --type String --overwrite 

aws ssm put-parameter --name "/cv-generator-fe/TERM" --value "cygwin" --type String --overwrite 

aws ssm put-parameter --name "/cv-generator-fe/CI" --value "false" --type String --overwrite 
# aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_AUDITING" --value "true" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_AUDITING" --value "false" --type String --overwrite 

aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_OVERRIDE_UPDATE_PACKAGES" --value "true" --type String --overwrite 

# # secure test
# aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_FE_SKIP_REDIRECT_TO_HTTPS" --value "false" --type String --overwrite 
# aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_FE_USE_SPDY" --value "true" --type String --overwrite 
# aws ssm put-parameter --name "/cv-generator-fe/NODE_TLS_REJECT_UNAUTHORIZED" --value "0" --type String --overwrite 
# aws ssm put-parameter --name "/cv-generator-fe/serverEndpointUri" --value "https://localhost:3000" --type String --overwrite 

# service pages
aws ssm put-parameter --name "/cv-generator-fe/ERROR_PAGE_URL" --value "https://d3v2pfjkkulyt1.cloudfront.net/application-error.html" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/MAINTENANCE_PAGE_URL" --value "https://d3v2pfjkkulyt1.cloudfront.net/maintenance-mode.html" --type String --overwrite 


# Launch configurations
#######################

# # local
# aws ssm put-parameter --name "/cv-generator-fe/serverEndpointUri" --value "http://localhost:3000" --type String --overwrite 
# aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_FE_DEBUG" --value "true" --type String --overwrite 
# # aws ssm put-parameter --name "/cv-generator-fe/CHROME_BIN" --value "" --type String --overwrite 

# # remote
# # # Do not modify the subdomein region! It's automatically managed by the install.sh script
# aws ssm put-parameter --name "/cv-generator-fe/serverEndpointUri" --value "https://cv-generator-project-server.herokuapp.com" --type String --overwrite 
# aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_FE_DEBUG" --value "true" --type String --overwrite 
# # aws ssm put-parameter --name "/cv-generator-fe/CHROME_BIN" --value "google-chrome" --type String --overwrite 

# # heroku
# # # Do not modify the subdomein region! It's automatically managed by the install.sh script
# aws ssm put-parameter --name "/cv-generator-fe/serverEndpointUri" --value "https://cv-generator-project-server.herokuapp.com" --type String --overwrite 
# aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_FE_DEBUG" --value "false" --type String --overwrite 
# aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_FE_SKIP_REDIRECT_TO_HTTPS" --value "false" --type String --overwrite 
# aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_OVERRIDE_UPDATE_PACKAGES" --value "false" --type String --overwrite 
# aws ssm put-parameter --name "/cv-generator-fe/CHROME_BIN" --value "/app/.apt/opt/google/chrome/chrome" --type String --overwrite 
# aws ssm put-parameter --name "/cv-generator-fe/CI" --value "true" --type String --overwrite 
# aws ssm put-parameter --name "/cv-generator-fe/HEROKU" --value "true" --type String --overwrite 
# aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_AUDITING" --value "true" --type String --overwrite 
# #
# # heroku old overrides (working)
# aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_AUDITING" --value "false" --type String --overwrite 
# aws ssm put-parameter --name "/cv-generator-fe/CV_GENERATOR_FE_SKIP_REDIRECT_TO_HTTPS" --value "true" --type String --overwrite 
# aws ssm put-parameter --name "/cv-generator-fe/NODEMODULESCACHE" --value "true" --type String --overwrite 

# superlocal thin
# # # Do not modify the subdomain region! It overrides the one automatically managed by the install.sh script
# aws ssm put-parameter --name "/cv-generator-fe/serverEndpointUri" --value "https://cv-generator-project-server-eu.herokuapp.com" --type String --overwrite 
# aws ssm put-parameter --name "/cv-generator-fe/serverEndpointUri" --value "http://localhost:3000" --type String --overwrite 
aws ssm put-parameter --name "/cv-generator-fe/serverEndpointUri" --value "https://fmfbhi92pn.eu-west-1.awsapprunner.com/" --type String --overwrite 


env | grep ^serverEndpointUri
env | grep ^DD_
env | grep ^NEW_RELIC_ENABLED
env | grep ^NODEMODULESCACHE
env | grep ^TERM
env | grep ^CI
env | grep ^NODE_TLS_REJECT_UNAUTHORIZED
echo
env | grep ^CV_GENERATOR_ | sort
echo
env | grep -e TOKEN -e KEY | sort
echo

echo
echo $'\033[1;32m'Environment set up.$'\033[0m'


echo
# read  -n 1 -p "x" input
# return