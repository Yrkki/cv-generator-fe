#!/bin/bash

echo $'\033[1;33m'Running environment setup script
echo ------------------------------------------------------$'\033[1;33m'
echo

echo $'\033[0;33m'Setting up environment...$'\033[0m'
echo
pwd=$(pwd)
pwd
ls -aF --color=always
echo

export CV_GENERATOR_FE_APP_PACKAGE_NAME=cv-generator-fe

# export CV_GENERATOR_FE_DEBUG=false
export CV_GENERATOR_FE_DEBUG=true

# export CV_GENERATOR_FE_SKIP_REDIRECT_TO_HTTPS=true
export CV_GENERATOR_FE_SKIP_REDIRECT_TO_HTTPS=false

# export CV_GENERATOR_FE_USE_SPDY=true
# export NODE_TLS_REJECT_UNAUTHORIZED=0
export CV_GENERATOR_FE_USE_SPDY=false
export NODE_TLS_REJECT_UNAUTHORIZED=1

export NODEMODULESCACHE=false

# # keychain
export NPM_TOKEN=42170b47-1dfa-44ef-b3cb-f3e00ae3fb8b
export CODECOV_TOKEN=b83acabe-5242-47bd-b085-3d01118049da
export CODACY_PROJECT_TOKEN=bc7b934f548541d88f3e01fcf141e545
export CODACY_API_TOKEN=0jDTZ9LSGPJX60KQDgCn
# export SNYK_TOKEN=05ff0e13-15d9-47d5-b3e0-90f94edfcda8    # @appveyor
# export SNYK_TOKEN=c66f807c-8a9a-439d-bc8b-dba6df8b10ff
export CV_GENERATOR_APPVEYOR_TOKEN=06i5dd4cg0rg9y3rjej4
export CV_GENERATOR_DOCKER_USERNAME=jorich
export CV_GENERATOR_DOCKER_TOKEN=723be3bd-50b7-4e99-bc1b-fe661fb61eb6
export CV_GENERATOR_GITHUB_TOKEN=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
export CV_GENERATOR_SONAR_TOKEN=0dd8ca76c1166fda12660c093f5d54d59cc71a85
export CV_GENERATOR_CODE_CLIMATE_TOKEN=62f633fb9575890afc28f3c473d032c31bed3bbb
export CV_GENERATOR_VELOCITY_DEPLOYMENT_TOKEN=62f633fb9575890afc28f3c473d032c31bed3bbb
# # other integrations
export DD_AGENT_MAJOR_VERSION=7
export DD_API_KEY=ac009977adcf4906389a7ca73d963623
export DD_SITE=datadoghq.eu
export NEW_RELIC_ENABLED=true

# # other config
export NPM_CONFIG_PRODUCTION=false

export TERM=cygwin

export CI=false
# export CV_GENERATOR_AUDITING=true
export CV_GENERATOR_AUDITING=false

export CV_GENERATOR_OVERRIDE_UPDATE_PACKAGES=true

# # secure test
# export CV_GENERATOR_FE_SKIP_REDIRECT_TO_HTTPS=false
# export CV_GENERATOR_FE_USE_SPDY=true
# export NODE_TLS_REJECT_UNAUTHORIZED=0
# export serverEndpointUri=https://localhost:3000


# Launch configurations
#######################

# # local
# export serverEndpointUri=http://localhost:3000
# export CV_GENERATOR_FE_DEBUG=true
# # export CHROME_BIN=

# # remote
# # # Do not modify the subdomein region! It's automatically managed by the install.sh script
# export serverEndpointUri=https://cv-generator-project-server.herokuapp.com
# export CV_GENERATOR_FE_DEBUG=true
# # export CHROME_BIN=google-chrome

# # heroku
# # # Do not modify the subdomein region! It's automatically managed by the install.sh script
# export serverEndpointUri=https://cv-generator-project-server.herokuapp.com
# export CV_GENERATOR_FE_DEBUG=false
# export CV_GENERATOR_FE_SKIP_REDIRECT_TO_HTTPS=false
# export CV_GENERATOR_OVERRIDE_UPDATE_PACKAGES=false
# export CHROME_BIN=/app/.apt/opt/google/chrome/chrome
# export CI=true
# export HEROKU=true
# export CV_GENERATOR_AUDITING=true
# #
# # heroku old overrides (working)
# export CV_GENERATOR_AUDITING=false
# export CV_GENERATOR_FE_SKIP_REDIRECT_TO_HTTPS=true
# export NODEMODULESCACHE=true

# superlocal thin
# # # Do not modify the subdomein region! It overrides the automatically managed by the install.sh script
export serverEndpointUri=https://cv-generator-project-server-eu.herokuapp.com
export serverEndpointUri=http://localhost:3000


env | grep ^serverEndpointUri
env | grep ^DD_
env | grep ^NEW_RELIC_ENABLED
env | grep ^NODEMODULESCACHE
env | grep ^TERM
env | grep ^CI
env | grep ^NODE_TLS_REJECT_UNAUTHORIZED
echo
env | grep ^CV_GENERATOR_ | sort
echo
env | grep -e TOKEN -e KEY | sort
echo

echo
echo $'\033[1;32m'Environment set up.$'\033[0m'


echo
# read  -n 1 -p "x" input
# return